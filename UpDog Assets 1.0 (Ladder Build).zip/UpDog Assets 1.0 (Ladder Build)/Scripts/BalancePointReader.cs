using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BalancePointReader : MonoBehaviour
{
    public GameObject gyro;
    public GameObject winbox;
    public float BP;
    Animator m_Animator;
    public bool tipover;
        public bool win;
        

    void Start()
    {
        //Get the animator, which you attach to the GameObject you are intending to animate.
        m_Animator = this.GetComponent<Animator>();

        tipover = false;
        win = winbox.GetComponent<topoftheladder>().top;
    }
    
    void Update()
    {
        BP = gyro.GetComponent<GyroRotation>().BalancePoints;
        m_Animator.SetFloat("Balance", BP);

        if (BP >= 20 || BP <= -20)
        {
            tipover = true;
        }

        if (win == true)
            {
                BP = 0;
            }
    }
}
