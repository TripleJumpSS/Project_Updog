using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class topoftheladder : MonoBehaviour
{
    public bool top;
    Animator m_Animator;
    public GameObject ladder;
    void Start()
    {
        top = false;
        m_Animator = ladder.GetComponent<Animator>();
    }


    // Update is called once per frame
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {

             top = true;
             m_Animator.SetBool("Top", true);

            }
}
}
