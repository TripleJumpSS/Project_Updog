using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class waterinmyeyes : MonoBehaviour
{
    public float pain;
    public Text paintext;
    public GameObject Gun;

    void Update()
    {
        paintext.text = "Pain: " + pain.ToString("00");

        if (pain == 200)
        {
            print("GAMEOVER");
            Gun.SetActive(false);
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Water")
        {
            pain += 1f;

        }
    }
}
