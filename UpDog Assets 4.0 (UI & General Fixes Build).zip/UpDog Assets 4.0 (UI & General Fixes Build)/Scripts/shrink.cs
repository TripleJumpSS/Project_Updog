using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class shrink : MonoBehaviour
{
    public GameObject cube;
    public Vector3 sizeChange;
    public Vector3 minsize;
    void Update()
    {
        if(transform.localScale.x < 0.09f)
        {
            cube.SetActive(false);
        }
    }

    // Update is called once per frame


    void OnTriggerEnter(Collider other)
        {
    if (other.gameObject.tag == "Water")
        {
            //Set the parent of that object to the platform

            cube.transform.localScale = cube.transform.localScale - sizeChange;

        }
        }
}
