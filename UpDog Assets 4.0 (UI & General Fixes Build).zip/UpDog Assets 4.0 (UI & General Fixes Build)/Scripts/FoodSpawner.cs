using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FoodSpawner : MonoBehaviour
{
    public GameObject DoogFood;

    public GameObject doogfoodprefab;
    public GameObject doogbiscuitsprefab;
    public GameObject chewtoyprefab;
    public GameObject tunafishprefab;
    public string lastfood;
    public GameObject Bucket;

    void Update()
    {
        DoogFood = GameObject.FindWithTag("Throwable");
        
        if (DoogFood == null)
        {
            switch(lastfood)
            {
        case "dogfood":
        Instantiate(doogfoodprefab, new Vector3(0.21f, 1.91f, -3.43f), Quaternion.identity);
        break;

        case "dogbiscuit":
        Instantiate(doogbiscuitsprefab, new Vector3(0.21f, 1.91f, -3.43f), Quaternion.identity);
        break;

        case "chewtoy":
        Instantiate(chewtoyprefab, new Vector3(0.21f, 1.91f, -3.43f), Quaternion.identity);
        break;

        case "tunafish":
        Instantiate(tunafishprefab, new Vector3(0.21f, 1.91f, -3.43f), Quaternion.identity);
        break;

        default:
        break;
            }


        }
    }

    void SpawnDogFood()
    {
        lastfood = "dogfood";
        Destroy(DoogFood);
        Instantiate(doogfoodprefab, new Vector3(0.21f, 1.91f, -3.43f), Quaternion.identity);
        Bucket.SetActive(false);
    }
    void SpawnDogBiscuit()
    {
        lastfood = "dogbiscuit";
        Destroy(DoogFood);
        Instantiate(doogbiscuitsprefab, new Vector3(0.21f, 1.91f, -3.43f), Quaternion.identity);
        Bucket.SetActive(false);
    }
    void SpawnChewToy()
    {
        lastfood = "chewtoy";
        Destroy(DoogFood);
        Instantiate(chewtoyprefab, new Vector3(0.21f, 1.91f, -3.43f), Quaternion.identity);
        Bucket.SetActive(false);
    }
    void SpawnTunaFish()
    {
        lastfood = "tunafish";
        Destroy(DoogFood);
        Instantiate(tunafishprefab, new Vector3(0.21f, 1.91f, -3.43f), Quaternion.identity);
        Bucket.SetActive(false);
    }
    void SpawnBucket()
    {
        lastfood = "bucket";
        Destroy(DoogFood);
        Bucket.SetActive(true);
    }

}
