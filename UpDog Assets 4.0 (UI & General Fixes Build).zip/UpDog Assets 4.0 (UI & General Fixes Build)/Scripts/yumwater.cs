using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class yumwater : MonoBehaviour
{
    public float drinkometer;
    public Text drinktext;

    void Update()
    {
        drinktext.text = "Drunk: " + drinkometer.ToString("00");
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Water")
        {
            drinkometer += 0.2f;

        }
    }
}
