using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WaypointsBackAndForth : MonoBehaviour
{
    public GameObject[] waypoints;
    int current = 0;
    public float speed;
    float WPradius = 1;
    public float HP;
    public float currentiframetime;
    public float normaliframetime;
    public float substanceiframetime;
    public bool iniframes;

    public Material defaultdog;
    public Material ghost;

    public Renderer Object;

    public Text HPtext;


    void Update()
    {
        transform.position = Vector3.MoveTowards(transform.position, waypoints[current].transform.position, Time.deltaTime * speed);
        HPtext.text = "HP: " + HP.ToString("0");

        if (Vector3.Distance(waypoints[current].transform.position, transform.position) < WPradius)
        {
            current++;
            if (current >= waypoints.Length)
            {
                current = 0;
            }
        }
        if (HP < 1)
        {
            //HP = 0;
            print("GameOver");
        }
    }

    void FixedUpdate()
    {
        if (currentiframetime > 0)
        {
            currentiframetime -= Time.deltaTime;
        }

        if (currentiframetime < 1)
        {
            currentiframetime = 0;
            GetComponent<MeshRenderer>().material = defaultdog;
            iniframes = false;
        }
    }

    
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Hazard")
        {
            if (iniframes == false) {HP -= 1;}
            iFrames();

        }

        if (other.gameObject.tag == "HeartBalloon")
        {
            HP += 1; 
        }
    }

    void iFrames()
    {
        if (iniframes == false)
        {
            iniframes = true;
            currentiframetime = normaliframetime;
            GetComponent<MeshRenderer>().material = ghost;
        }
    }

    void SubstanceiFrames()
    {
            iniframes = true;
            currentiframetime = substanceiframetime;
            GetComponent<MeshRenderer>().material = ghost;
     }
    
}
    

