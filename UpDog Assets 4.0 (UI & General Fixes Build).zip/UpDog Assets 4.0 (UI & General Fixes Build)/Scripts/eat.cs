using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class eat : MonoBehaviour
{
    public GameObject poop;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
    }


    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Throwable")
        {
            var number = Random.Range(1,10);
            print(number);
            if(number == 5)
            {Instantiate(poop, new Vector3(0.2360384f, 14.88f, 7.777f), Quaternion.identity);}

        }
    }
}
