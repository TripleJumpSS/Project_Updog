using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class firewater : MonoBehaviour
{
    public GameObject WaterPrefab;
    public float fireRate = 0.5F;
  private float nextFire = 0.0F;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

        if(Input.GetKey(KeyCode.Mouse0) && Time.time > nextFire)
    {
        nextFire = Time.time + fireRate;
        Instantiate(WaterPrefab, transform.position, transform.rotation);
    }
        
    }

    

    
}
