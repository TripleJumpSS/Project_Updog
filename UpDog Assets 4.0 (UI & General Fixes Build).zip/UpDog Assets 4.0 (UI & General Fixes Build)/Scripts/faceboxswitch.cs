using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class faceboxswitch : MonoBehaviour
{
    public GameObject facebox;
    public GameObject painbox;
    public float timeRemaining;
    public float MaxTime;
    // Start is called before the first frame update
    void Start()
    {
        timeRemaining = 1;
        facebox.SetActive(true);
            painbox.SetActive(true);
    }

    void FixedUpdate()
    {
        if (timeRemaining > 0)
        {
            
            timeRemaining -= Time.deltaTime;
            

        }
        if (timeRemaining < 0)
        {
            
            timeRemaining = MaxTime;

        }

        if (timeRemaining > 3)
        {
            
            facebox.SetActive(true);
            painbox.SetActive(false);

        }

        if (timeRemaining < 3)
        {
            
            facebox.SetActive(false);
            painbox.SetActive(true);


        }
    }
}
