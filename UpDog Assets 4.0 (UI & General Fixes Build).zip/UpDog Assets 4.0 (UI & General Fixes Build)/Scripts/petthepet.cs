using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class petthepet : MonoBehaviour
{
    public bool win;
    public GameObject winbox;
    public GameObject BoxHero;
    public MeshRenderer MR;
    public Transform TR;
    public float petnum;
    public Text PetNumtext;
    public Text Countdowntext;
    public Text Prompt;

    public GameObject CountdowntextGO;
    public GameObject PetNumGO;

    public float countdown;
    public float maxtime;


    void Start()
    {
        this.enabled = true;
        TR.GetComponent<Collider>().isTrigger = false;
        MR.enabled = false;
        countdown = maxtime;
        Prompt.text = "Keep the Ladder Steady!";
        PetNumGO.SetActive(false);
        CountdowntextGO.SetActive(false);


    }

    void Update()
    {
        win = winbox.GetComponent<topoftheladder>().top;
        PetNumtext.text = petnum.ToString("0");
        Countdowntext.text = "Time Left:" + countdown.ToString("0");

        if (win == true)
        {
            PetNumGO.SetActive(true);
            CountdowntextGO.SetActive(true);

            TR.GetComponent<Collider>().isTrigger = true;
            MR.enabled = true;
            countdown -= Time.deltaTime;
            Prompt.text = "Rub his head until time runs out!";

        }

        if (countdown <1)
        {
            BoxHero.SendMessage("GameOver");
            countdown = 0;
            Prompt.text = "Good Job!";
            PetNumGO.SetActive(false);
            CountdowntextGO.SetActive(false);

        }
    }

    void OnTriggerExit(Collider other)
    {

        //If the object that is colliding has the tag "Tag"
        if (other.gameObject.tag == "Cursor")
        {
            petnum += 1;
        }
    }
}
