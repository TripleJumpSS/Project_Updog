using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class divedown : MonoBehaviour
{
    private Rigidbody rb;
    public float speed;
    
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        
    }
    void Button()
    {
        rb.AddForce(-transform.up * speed);
    }
}
