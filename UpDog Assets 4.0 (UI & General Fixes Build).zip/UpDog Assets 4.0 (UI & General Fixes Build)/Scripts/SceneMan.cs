using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneMan : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    public void LoadIdleScene()
    {
        SceneManager.LoadScene(0);
    }

    public void LoadTossScene()
    {
        SceneManager.LoadScene(1);
    }

    public void LoadSprayScene()
    {
        SceneManager.LoadScene(2);
    }

    public void LoadDrinkScene()
    {
        SceneManager.LoadScene(3);
    }

    public void LoadWalkScene()
    {
        SceneManager.LoadScene(4);
    }

    public void LoadLadderScene()
    {
        SceneManager.LoadScene(5);
    }

    public void LoadShopScene()
    {
        SceneManager.LoadScene(6);
    }
}

