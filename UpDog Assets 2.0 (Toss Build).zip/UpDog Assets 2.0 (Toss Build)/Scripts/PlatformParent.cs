using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatformParent : MonoBehaviour
{
    public bool clickable;
    public bool throwable;
    private Rigidbody rb;
    public float UpForce;
    public float FrontForce;
    public GameObject thisthing;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    void Update()
    {
        if (Input.GetMouseButton(0))
        {
            if (clickable == true)
            { 
                this.transform.parent = GameObject.Find("Cursor").transform;
                throwable = true;
            }
        }
        if (Input.GetMouseButtonUp(0))
        {
            this.rb.useGravity = true;
            this.transform.parent = null;
            if (throwable == true)
            {
                throwable = false;
                rb.AddForce(transform.up * UpForce);
                rb.AddForce(transform.forward * FrontForce);
            }

        }
    }

        void OnTriggerEnter(Collider other)
        {

            //If the object that is colliding has the tag "Tag"
            if (other.gameObject.tag == "Cursor")
            {
                //Set the parent of that object to the platform

                clickable = true;

            }

        if (other.gameObject.tag == "EatBox")
        {
            //Set the parent of that object to the platform

            Destroy(thisthing);

        }

        if (other.gameObject.tag == "Wall")
        {
            //Set the parent of that object to the platform

            Destroy(thisthing);

        }

    }
        void OnTriggerExit(Collider other)
        {

            //If the object that is colliding has the tag "Tag"
            if (other.gameObject.tag == "Cursor")
            {
                //Set the parent of that object to the platform
                clickable = false;
            }
        }
    }
    
