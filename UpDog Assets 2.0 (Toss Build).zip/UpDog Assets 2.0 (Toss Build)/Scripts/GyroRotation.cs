using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GyroRotation : MonoBehaviour
{
public float BalancePoints;
public bool speed;
public bool halfspeed;
public bool maxspeed;
public float gyroinfo;
public float timeRemaining;
public float MaxTime;

public GameObject winbox;
public bool win;
public MeshRenderer MR;

public Text BPtext;
void Start ()
     {
         MR = GetComponent<MeshRenderer>();
         Input.gyro.enabled = true;
         this.transform.rotation = new Quaternion(0,0,0,0);
         timeRemaining = MaxTime;
         win = winbox.GetComponent<topoftheladder>().top;
     }

void Update ()
     {
         this.transform.Rotate (0, 0, Input.gyro.rotationRateUnbiased.z / 5);
         gyroinfo = this.transform.rotation.z;
        BPtext.text = "BP = " + BalancePoints.ToString("00");
        win = winbox.GetComponent<topoftheladder>().top;

        if (win == true)
            {
                MR.enabled = false;

            }

     }


void FixedUpdate()
    {
        if (timeRemaining > 0)
        {
            
            timeRemaining -= Time.deltaTime;
            

        }
        if (timeRemaining < 0)
        {
            
            timeRemaining = MaxTime;
            AwardPoint();
            

        }
    }

void Calibrate()
{
    this.transform.rotation = new Quaternion(0,0,0,0);
}

void AwardPoint()
{
        //if gyroinfo is SMALLER/RIGHT
        //smaller than 0, bigger than -0.04;
        if(gyroinfo <= 0f && gyroinfo >= -0.04)
        {
            
            BalancePoints -= 2f;
            speed = false;
            halfspeed = false;
            maxspeed = false;
        }
        //smaller than 0.04, bigger than -0.1;
        if(gyroinfo <= -0.04f && gyroinfo >= -0.1)
        {
            
            BalancePoints -= 4f;
            speed = false;
            halfspeed = true;
            maxspeed = false;
        }
        //smaller than -0.1, bigger than -0.2;
        if(gyroinfo <= -0.1f && gyroinfo >= -0.2)
        {
            
            BalancePoints -= 5f;
            speed = true;
            halfspeed = false;
            maxspeed = false;
        }
        //smaller than -0.2;
        if(gyroinfo <= -0.2)
        {
            
            BalancePoints -= 6f;
            speed = false;
            halfspeed = false;
            maxspeed = true;
        }


        //if gyroinfo is BIGGER/LEFT
        //bigger than 0, smaller than 0.04;
        if(gyroinfo >= 0f && gyroinfo <= 0.04f)
        {
            
            BalancePoints += 2f;
            speed = false;
            halfspeed = false;
            maxspeed = false;
        }
        //bigger than 0.04, smaller than 0.1;
        if(gyroinfo >= 0.04f && gyroinfo <= 0.1f)
        {
            
            BalancePoints += 4f;
            speed = false;
            halfspeed = true;
            maxspeed = false;
        }

        //bigger than 0.1, smaller than 0.2;
        if(gyroinfo >= 0.1f && gyroinfo <= 0.2)
        {
            
            BalancePoints += 5f;
            speed = true;
            halfspeed = false;
            maxspeed = false;
        }
        //bigger than 0.2;
        if(gyroinfo >= 0.2f)
        {
            
            BalancePoints += 6f;
            speed = false;
            halfspeed = false;
            maxspeed = true;
        }

        
}

}

