using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class waterfire : MonoBehaviour
{
    public float speed;
    public float upspeed;
    public GameObject thisthing;
   
    

    

    // Start is called before the first frame update
    

    void Update()
    {
        transform.Translate(Vector3.forward * speed * Time.deltaTime);
        transform.Translate(Vector3.up * upspeed * Time.deltaTime);
    }

    void OnTriggerEnter(Collider other)
        {
    if (other.gameObject.tag == "Wall")
        {
            //Set the parent of that object to the platform

            Destroy(thisthing);

        }
        }
}
