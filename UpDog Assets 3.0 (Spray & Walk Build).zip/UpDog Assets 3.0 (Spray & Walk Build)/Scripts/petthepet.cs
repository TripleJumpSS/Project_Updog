using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class petthepet : MonoBehaviour
{
    public bool win;
    public GameObject winbox;
    public MeshRenderer MR;
    public Transform TR;


    void Start()
    {
        this.enabled = true;
        TR.GetComponent<Collider>().isTrigger = false;
        MR.enabled = false;
    }

    void Update()
    {
        win = winbox.GetComponent<topoftheladder>().top;
        if (win == true)
        {
            TR.GetComponent<Collider>().isTrigger = true;
            MR.enabled = true;

        }
    }

    void OnTriggerExit(Collider other)
    {

        //If the object that is colliding has the tag "Tag"
        if (other.gameObject.tag == "Cursor")
        {
            print("*pets*");
        }
    }
}
