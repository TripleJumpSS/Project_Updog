using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class glide_up : MonoBehaviour
{
    private Vector3 mousePosition;
    private Rigidbody rb;
    private Vector3 direction;
    public float moveSpeed;
    public GameObject ladder;
    public GameObject winbox;
    public bool tippedover;
    public bool win;

    // Use this for initialization
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        tippedover = false;
    }

    // Update is called once per frame
    void Update()
    {
        tippedover = ladder.GetComponent<BalancePointReader>().tipover;
        win = winbox.GetComponent<topoftheladder>().top;
        
            
            mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            direction = (mousePosition - transform.position).normalized;
            rb.velocity = new Vector3(direction.x * moveSpeed, direction.y * moveSpeed, direction.z - direction.z);
            
            if (tippedover == true)
            {
                moveSpeed = -150;
                this.rb.useGravity = true;

            }

            if (win == true)
            {
                moveSpeed = 0;
                this.rb.useGravity = false;

            }

        
        
          
    }
}
