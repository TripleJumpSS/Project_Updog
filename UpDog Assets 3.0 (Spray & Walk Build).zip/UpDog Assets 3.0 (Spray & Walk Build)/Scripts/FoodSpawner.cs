using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FoodSpawner : MonoBehaviour
{
    public GameObject DoogFood;

    public GameObject newfoodPrefab;

    void Update()
    {
        DoogFood = GameObject.FindWithTag("Throwable");
    }

    void Button()
    {
        if (DoogFood == null)
        {
            Instantiate(newfoodPrefab, new Vector3(0.21f, 1.91f, -3.43f), Quaternion.identity);

        }
    }

}
